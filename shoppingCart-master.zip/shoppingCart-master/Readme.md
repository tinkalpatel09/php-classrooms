simple  class for working with shopping cart, based on sessions.
Add folder ShoppingCarrt in src/ of your project.
