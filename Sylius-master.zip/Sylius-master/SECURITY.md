# Security Policy

## Reporting a Vulnerability

If you think that you have found a security issue in Sylius, please do not use the issue tracker and do not post it publicly. Instead, all security issues must be sent to security@sylius.com.

## Supported Versions (security updates)

Please refer to [the release process](https://docs.sylius.com/en/latest/contributing/organization/release-process.html#past-releases).
