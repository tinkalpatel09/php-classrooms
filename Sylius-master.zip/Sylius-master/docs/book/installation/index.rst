Installation
============

The process of installing Sylius together with the requirements to run it efficiently.

.. toctree::
    :hidden:

    requirements
    installation
    upgrading

.. include:: /book/installation/map.rst.inc
