Introduction
============

This is the beginning of the journey with Sylius. We will start with a basic insight into terms that we use in Sylius Documentation.

.. toctree::
    :hidden:

    introduction
    environments

.. include:: /book/introduction/map.rst.inc
