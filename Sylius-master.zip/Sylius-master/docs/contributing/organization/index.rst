Organization
============

.. toctree::
    :hidden:

    vision-and-strategy
    core-team
    release-process

.. include:: /contributing/organization/map.rst.inc
