Contributing Translations
=========================

Sylius application is fully translatable, and what is more it is translated by the community to a variety of languages!

Sylius translations are kept on `Crowdin <http://translate.sylius.com>`_.

How to contribute translations in any language?
-----------------------------------------------

The process of submitting new translations in any existing language is really simple:

1. First of all you need an account on Crowdin. If do not have one, please `sign up <https://crowdin.com/join>`_.
2. Find a piece of Sylius and translate it to chosen language `here <http://translate.sylius.com>`_.
3. After approval from the Crowdin community it will be automatically synced into the main repository.

That's all! You can start translating.
