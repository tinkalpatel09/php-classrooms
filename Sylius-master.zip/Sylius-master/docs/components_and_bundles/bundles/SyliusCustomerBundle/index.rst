.. rst-class:: outdated

SyliusCustomerBundle
====================

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

A solution for customer management system inside of a Symfony application.

.. toctree::
   :numbered:

   installation
   summary

Learn more
----------

* :doc:`Customers in the Sylius platform </book/customers/index>` - concept documentation
