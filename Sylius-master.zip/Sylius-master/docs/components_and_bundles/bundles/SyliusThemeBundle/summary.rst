Summary
=======

Tests
-----

.. code-block:: bash

    $ composer install
    $ vendor/bin/phpspec run -f pretty
    $ vendor/bin/phpunit

Bug tracking
------------

This bundle uses `GitHub issues <https://github.com/Sylius/Sylius/issues>`_.
If you have found bug, please create an issue.
