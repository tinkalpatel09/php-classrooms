SyliusThemeBundle
=================

Flexible theming system for Symfony applications.

.. toctree::
    :numbered:
    :maxdepth: 2

    installation
    your_first_theme
    important_changes
    configuration_sources
    theme_inheritance
    theme_configuration_reference
    summary

Learn more
----------

* :doc:`Themes in the Sylius platform </book/themes/index>` - concept documentation
