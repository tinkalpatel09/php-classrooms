.. rst-class:: outdated

Default calculators
===================

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Default calculators can be sufficient solution for many use cases.

Flat rate
---------

The ``flat_rate`` calculator, charges concrete amount per shipment.

Per item rate
-------------

The ``per_item_rate`` calculator, charges concrete amount per shipment item.

More calculators
----------------

Depending on community contributions and Sylius resources, more default calculators can be implemented, for example ``weight_range_rate``.
