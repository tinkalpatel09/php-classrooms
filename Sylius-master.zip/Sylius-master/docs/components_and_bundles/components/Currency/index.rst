.. rst-class:: outdated

Currency
========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Managing different currencies, exchange rates and converting cash amounts for PHP applications.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces
   unavailable_currency_exception

Learn more
----------

* :doc:`Currencies in the Sylius platform </book/configuration/currencies>` - concept documentation
