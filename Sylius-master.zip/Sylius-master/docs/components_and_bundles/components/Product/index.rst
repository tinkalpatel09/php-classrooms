.. rst-class:: outdated

Product
=======

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Powerful products catalog for PHP applications.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces

Learn more
----------

* :doc:`Products in the Sylius platform </book/products/index>` - concept documentation
