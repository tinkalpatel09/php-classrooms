.. rst-class:: outdated

Mailer
======

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Sylius Mailer component abstracts the process of sending e-mails. It also provides interface to configure various parameters for unique e-mails.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces

Learn more
----------

* :doc:`Emails in the Sylius platform </book/architecture/emails>` - concept documentation
