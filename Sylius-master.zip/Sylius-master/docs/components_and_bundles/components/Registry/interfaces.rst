.. rst-class:: outdated

Interfaces
==========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

.. _component_registry_service-registry-interface:

ServiceRegistryInterface
------------------------

This interface should be implemented by a service responsible for managing various services.

.. note::
   For more detailed information go to `Sylius API ServiceRegistryInterface`_.

.. _Sylius API ServiceRegistryInterface: http://api.sylius.com/Sylius/Component/Registry/ServiceRegistryInterface.html
