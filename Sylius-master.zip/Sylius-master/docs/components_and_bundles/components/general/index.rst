Components General Guide
========================

All Sylius components have very similar structure and this guide will introduce you these conventions.

Through this documentation, you will learn how to install and use them in any PHP application.

.. toctree::
    :maxdepth: 1

    using_components
    what_is_resource
    creating_resources
