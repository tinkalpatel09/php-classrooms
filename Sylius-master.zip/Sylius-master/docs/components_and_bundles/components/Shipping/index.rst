.. rst-class:: outdated

Shipping
========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Shipments and shipping methods management for PHP E-Commerce applications. It contains flexible calculators system for computing the shipping costs.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   calculators
   checkers
   models
   interfaces
   state_machine

Learn more
----------

* :doc:`Shipments in the Sylius platform </book/orders/shipments>` - concept documentation
