.. rst-class:: outdated

Locale
======

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Managing different locales for PHP apps.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces

Learn more
----------

* :doc:`Locales in the Sylius platform </book/configuration/locales>` - concept documentation
