.. rst-class:: outdated

User
====

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Users management implementation in PHP.

.. toctree::
   :maxdepth: 2

   installation
   models
   basic_usage

Learn more
----------

* :doc:`Customers & Users in the Sylius platform </book/customers/index>` - concept documentation
