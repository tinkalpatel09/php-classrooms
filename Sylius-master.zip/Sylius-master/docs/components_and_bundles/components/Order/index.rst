.. rst-class:: outdated

Order
=====

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

E-Commerce PHP library for creating and managing sales orders.

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   models
   interfaces
   state_machine
   processors

Learn more
----------

* :doc:`Carts & Orders in the Sylius platform </book/orders/index>` - concept documentation
