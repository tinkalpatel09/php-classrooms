.. rst-class:: outdated

Grid
====

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Sylius component used for describing data grids. Decoupled from Symfony and useful for any kind of system, which needs to provide user with grid functionality.

.. toctree::
   :numbered:

   installation
   summary
