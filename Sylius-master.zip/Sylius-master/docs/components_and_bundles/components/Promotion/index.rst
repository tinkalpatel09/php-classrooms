.. rst-class:: outdated

Promotion
=========

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

Super-flexible promotions system with support of complex rules and actions. Coupon codes included!

.. toctree::
   :maxdepth: 2

   installation
   basic_usage
   checkers
   models
   interfaces

Learn more
----------

* :doc:`Promotions in the Sylius platform </book/orders/promotions>` - concept documentation
