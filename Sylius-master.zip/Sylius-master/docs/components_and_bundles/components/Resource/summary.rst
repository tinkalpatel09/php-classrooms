Summary
=======

`phpspec <http://phpspec.net>`_ examples
-----------------------------------------

.. code-block:: bash

    $ composer install
    $ vendor/bin/phpspec run -fpretty --verbose

Bug tracking
------------

This component uses `GitHub issues <https://github.com/Sylius/Sylius/issues>`_.
If you have found bug, please create an issue.
