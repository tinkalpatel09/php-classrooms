.. rst-class:: outdated

Installation
============

.. danger::

   We're sorry but **this documentation section is outdated**. Please have that in mind when trying to use it.
   You can help us making documentation up to date via Sylius Github. Thank you!

You can install the component in 2 different ways:

* :doc:`Install it via Composer </components_and_bundles/components/general/using_components>` (``sylius/attribute`` on `Packagist`_).
* Use the official Git repository (https://github.com/Sylius/Attribute).

.. include:: /components_and_bundles/components/require_autoload.rst.inc

.. _Packagist: https://packagist.org/packages/sylius/attribute
