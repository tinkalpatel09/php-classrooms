---
name: "Documentation Issue 📖"
about: Report missing or bugged documentation

---

**Sylius docs version**: 1.x / latest

**Description**
<!-- Describe what is missing or where exactly is the bug/typo/issue located. Links highly appreciated. --!>
