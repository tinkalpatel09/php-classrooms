---
name: "Bug Report 🐛"
about: Report a problem or error

---


**Sylius version affected**: 1.x.y

**Description**  
<!-- A clear and concise description of the bug you are experiencing. -->

**Steps to reproduce**  
<!-- Code and/or configuration required to reproduce the bug. -->

**Possible Solution**  
<!--- Optional: if you have any suggestions on a fix/reason for the bug -->
