---
name: "Support Question 🚫"
about: See http://docs.sylius.com/en/latest/support/index.html for questions about
  using Sylius

---

We use GitHub issues only to discuss about Sylius bugs, new features and documentation. 
For this kind of questions about Sylius usage, please use
any of the support alternatives described here: http://docs.sylius.com/en/latest/support/index.html

Thank you!
