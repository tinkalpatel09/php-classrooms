---
name: "Security Issue 🔐"
about: Please contact us at security@sylius.com

---

If you think that you have found a security issue in Sylius, please do not use the issue tracker and do not post it publicly. 
Instead, all security issues must be sent to `security@sylius.com`.
