| Q                | A
| ---------------- | -----
| Bug report?      | no/yes
| Feature request? | no/yes
| BC Break report? | no/yes
| RFC?             | no/yes
| Sylius version   | 1.x.y

<!--
 - For support requests and how-tos, visit http://docs.sylius.com/en/latest/support/
-->
