<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* bill.html.twig */
class __TwigTemplate_ad3f5e7a4a75467d2a0470cdcdbc1fea783820eb04f32f78d13f594e7aab6213 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'active_contact' => [$this, 'block_active_contact'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bill.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "bill.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->displayBlock('active_contact', $context, $blocks);
        // line 3
        echo "


";
        // line 6
        $this->displayBlock('body', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_active_contact($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        echo " active ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<style>.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

span.price {
  float: right;
  color: grey;
}


@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}</style>
<div class=\"row\">
  <div class=\"col-75\">
    <div class=\"container\">
      

        <div class=\"row\">
          <div class=\"col-50\">
            <h3>Billing Address</h3>
            <label for=\"fname\"><i class=\"fa fa-user\"></i> Full Name</label>
            <input type=\"text\" id=\"fname\" name=\"firstname\" placeholder=\"John M. Doe\">
            <label for=\"email\"><i class=\"fa fa-envelope\"></i> Email</label>
            <input type=\"text\" id=\"email\" name=\"email\" placeholder=\"john@example.com\">
            <label for=\"adr\"><i class=\"fa fa-address-card-o\"></i> Address</label>
            <input type=\"text\" id=\"adr\" name=\"address\" placeholder=\"542 W. 15th Street\">
            <label for=\"city\"><i class=\"fa fa-institution\"></i> City</label>
            <input type=\"text\" id=\"city\" name=\"city\" placeholder=\"New York\">

            <div class=\"row\">
              <div class=\"col-50\">
                <label for=\"state\">State</label>
                <input type=\"text\" id=\"state\" name=\"state\" placeholder=\"NY\">
              </div>
              <div class=\"col-50\">
                <label for=\"zip\">Zip</label>
                <input type=\"text\" id=\"zip\" name=\"zip\" placeholder=\"10001\">
              </div>
            </div>
          </div>

          <div class=\"col-50\">
            <h3>Payment</h3>
            <label for=\"fname\">Accepted Cards</label>
            <div class=\"icon-container\">
              <i class=\"fa fa-cc-visa\" style=\"color:navy;\"></i>
              <i class=\"fa fa-cc-amex\" style=\"color:blue;\"></i>
              <i class=\"fa fa-cc-mastercard\" style=\"color:red;\"></i>
              <i class=\"fa fa-cc-discover\" style=\"color:orange;\"></i>
            </div>
            <label for=\"cname\">Name on Card</label>
            <input type=\"text\" id=\"cname\" name=\"cardname\" placeholder=\"John More Doe\">
            <label for=\"ccnum\">Credit card number</label>
            <input type=\"text\" id=\"ccnum\" name=\"cardnumber\" placeholder=\"1111-2222-3333-4444\">
            <label for=\"expmonth\">Exp Month</label>
            <input type=\"text\" id=\"expmonth\" name=\"expmonth\" placeholder=\"September\">

            <div class=\"row\">
              <div class=\"col-50\">
                <label for=\"expyear\">Exp Year</label>
                <input type=\"text\" id=\"expyear\" name=\"expyear\" placeholder=\"2018\">
              </div>
              <div class=\"col-50\">
                <label for=\"cvv\">CVV</label>
                <input type=\"text\" id=\"cvv\" name=\"cvv\" placeholder=\"352\">
              </div>
            </div>
          </div>

        </div>
        <label>
          <input type=\"checkbox\" checked=\"checked\" name=\"sameadr\"> Shipping address same as billing
        </label>
        <input type=\"submit\" value=\"Continue to checkout\" class=\"btn\">
      </form>
    </div>
  </div>

  <div class=\"col-25\">
    <div class=\"container\">
      <h4>Cart
        <span class=\"price\" style=\"color:black\">
          <i class=\"fa fa-shopping-cart\"></i>
          <b>4</b>
        </span>
      </h4>
      <p><a href=\"";
        // line 166
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product");
        echo "\">Product 1</a> <span class=\"price\">\$200</span></p>
      <p><a href=\"";
        // line 167
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product");
        echo "\">Product 2</a> <span class=\"price\">\$700</span></p>
      <p><a href=\"";
        // line 168
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("product");
        echo "\">Product 3</a> <span class=\"price\">\$349</span></p>
      
      <hr>
      <p>Total <span class=\"price\" style=\"color:black\"><b>\$1249</b></span></p>
    </div>
  </div>
</div>


    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bill.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  263 => 168,  259 => 167,  255 => 166,  94 => 7,  84 => 6,  65 => 2,  55 => 6,  50 => 3,  48 => 2,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
{% block active_contact %} active {% endblock %}



{% block body %}
<style>.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

span.price {
  float: right;
  color: grey;
}


@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}</style>
<div class=\"row\">
  <div class=\"col-75\">
    <div class=\"container\">
      

        <div class=\"row\">
          <div class=\"col-50\">
            <h3>Billing Address</h3>
            <label for=\"fname\"><i class=\"fa fa-user\"></i> Full Name</label>
            <input type=\"text\" id=\"fname\" name=\"firstname\" placeholder=\"John M. Doe\">
            <label for=\"email\"><i class=\"fa fa-envelope\"></i> Email</label>
            <input type=\"text\" id=\"email\" name=\"email\" placeholder=\"john@example.com\">
            <label for=\"adr\"><i class=\"fa fa-address-card-o\"></i> Address</label>
            <input type=\"text\" id=\"adr\" name=\"address\" placeholder=\"542 W. 15th Street\">
            <label for=\"city\"><i class=\"fa fa-institution\"></i> City</label>
            <input type=\"text\" id=\"city\" name=\"city\" placeholder=\"New York\">

            <div class=\"row\">
              <div class=\"col-50\">
                <label for=\"state\">State</label>
                <input type=\"text\" id=\"state\" name=\"state\" placeholder=\"NY\">
              </div>
              <div class=\"col-50\">
                <label for=\"zip\">Zip</label>
                <input type=\"text\" id=\"zip\" name=\"zip\" placeholder=\"10001\">
              </div>
            </div>
          </div>

          <div class=\"col-50\">
            <h3>Payment</h3>
            <label for=\"fname\">Accepted Cards</label>
            <div class=\"icon-container\">
              <i class=\"fa fa-cc-visa\" style=\"color:navy;\"></i>
              <i class=\"fa fa-cc-amex\" style=\"color:blue;\"></i>
              <i class=\"fa fa-cc-mastercard\" style=\"color:red;\"></i>
              <i class=\"fa fa-cc-discover\" style=\"color:orange;\"></i>
            </div>
            <label for=\"cname\">Name on Card</label>
            <input type=\"text\" id=\"cname\" name=\"cardname\" placeholder=\"John More Doe\">
            <label for=\"ccnum\">Credit card number</label>
            <input type=\"text\" id=\"ccnum\" name=\"cardnumber\" placeholder=\"1111-2222-3333-4444\">
            <label for=\"expmonth\">Exp Month</label>
            <input type=\"text\" id=\"expmonth\" name=\"expmonth\" placeholder=\"September\">

            <div class=\"row\">
              <div class=\"col-50\">
                <label for=\"expyear\">Exp Year</label>
                <input type=\"text\" id=\"expyear\" name=\"expyear\" placeholder=\"2018\">
              </div>
              <div class=\"col-50\">
                <label for=\"cvv\">CVV</label>
                <input type=\"text\" id=\"cvv\" name=\"cvv\" placeholder=\"352\">
              </div>
            </div>
          </div>

        </div>
        <label>
          <input type=\"checkbox\" checked=\"checked\" name=\"sameadr\"> Shipping address same as billing
        </label>
        <input type=\"submit\" value=\"Continue to checkout\" class=\"btn\">
      </form>
    </div>
  </div>

  <div class=\"col-25\">
    <div class=\"container\">
      <h4>Cart
        <span class=\"price\" style=\"color:black\">
          <i class=\"fa fa-shopping-cart\"></i>
          <b>4</b>
        </span>
      </h4>
      <p><a href=\"{{ path('product') }}\">Product 1</a> <span class=\"price\">\$200</span></p>
      <p><a href=\"{{ path('product') }}\">Product 2</a> <span class=\"price\">\$700</span></p>
      <p><a href=\"{{ path('product') }}\">Product 3</a> <span class=\"price\">\$349</span></p>
      
      <hr>
      <p>Total <span class=\"price\" style=\"color:black\"><b>\$1249</b></span></p>
    </div>
  </div>
</div>


    {% endblock %}", "bill.html.twig", "C:\\xampp\\htdocs\\EleQ\\templates\\bill.html.twig");
    }
}
