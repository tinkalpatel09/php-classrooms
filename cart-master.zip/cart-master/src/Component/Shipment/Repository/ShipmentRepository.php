<?php

declare(strict_types=1);

namespace App\Component\Shipment\Repository;

use Doctrine\ORM\EntityRepository;

class ShipmentRepository extends EntityRepository
{
}