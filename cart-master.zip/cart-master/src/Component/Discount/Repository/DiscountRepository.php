<?php

declare(strict_types=1);

namespace App\Component\Discount\Repository;

use Doctrine\ORM\EntityRepository;

class DiscountRepository extends EntityRepository
{
}