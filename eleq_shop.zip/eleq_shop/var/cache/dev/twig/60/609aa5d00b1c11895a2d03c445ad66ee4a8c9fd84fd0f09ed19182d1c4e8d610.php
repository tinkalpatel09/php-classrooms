<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* contact.html.twig */
class __TwigTemplate_a28ebb41dacfd535441327a08ad2e564a4906ff6bba110775778839d864ba1bb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'active_contact' => [$this, 'block_active_contact'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "contact.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_active_contact($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        echo " active ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
<div class=\"hs-wel\">
<div class=\"container\">
  <div class=\"row\">
    <div class=\"col-12\">
     <a href=\"#\">
      <i class=\"fas fa-home\"></i>
     </a>
     <span>/</span>
    <span>Contact us</span>
   <span>/</span>
    <span>Welcome to MX Electronics</span>
    </div>
   </div>
  </div>
</div>
<div class=\"container-fluid\">
  <div class=\"row\">
    <div class=\"col-12\">
      <iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2796.9178614085017!2d-73.58371338515593!3d45.491598779101274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cc91a6c597e5669%3A0x8dbf497cbd80d838!2sColl%C3%A8ge%20LaSalle!5e0!3m2!1sen!2sca!4v1576782813196!5m2!1sen!2sca\" width=\"100%\" height=\"350\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\"></iframe>
    </div>
   </div>
</div>
<div class=\"container\">
  <div class=\"row\">
    <div class=\"col-12\">
  <div class=\"hs-ad\">
<i class=\"fas fa-map-marker-alt\"></i>
  <span>Highway 7 Leslie Street 75 West Wilmot St. Richmond Hill, Ontario L4B 0B7, Canada</span>
</div>
<div class=\"hs-ad\">
  <i class=\"fas fa-mobile-alt\"></i>
    <span>+1(514)566-0432</span>
</div>
<div class=\"hs-ad\">
  <i class=\"fas fa-phone-volume\"></i>
    <span>+1(514)566-0564</span>
</div>
<div class=\"hs-ad\">
  <i class=\"fas fa-phone-volume\"></i>
   <span>+1(514)566-4532</span>
</div>
</div>
</div>
</div>
<div class=\"container-fluid hs-footer\">
  <div class=\"row\">
   <div class=\"col-6\">
    <i class=\"far fa-copyright\"></i>
     <span>Designed by Nourolhoda Sayadi</span>
   </div>
     <div class=\"col-6 text-right social\">
      <i class=\"fab fa-twitter\"></i>
      <i class=\"fab fa-google-plus-g\"></i>
      <i class=\"fab fa-instagram\"></i>
      <i class=\"fab fa-facebook-f\"></i>
     </div>
   </div>
 </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends ('base.html.twig') %}

{% block active_contact %} active {% endblock %}

{% block body %}

<div class=\"hs-wel\">
<div class=\"container\">
  <div class=\"row\">
    <div class=\"col-12\">
     <a href=\"#\">
      <i class=\"fas fa-home\"></i>
     </a>
     <span>/</span>
    <span>Contact us</span>
   <span>/</span>
    <span>Welcome to MX Electronics</span>
    </div>
   </div>
  </div>
</div>
<div class=\"container-fluid\">
  <div class=\"row\">
    <div class=\"col-12\">
      <iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2796.9178614085017!2d-73.58371338515593!3d45.491598779101274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cc91a6c597e5669%3A0x8dbf497cbd80d838!2sColl%C3%A8ge%20LaSalle!5e0!3m2!1sen!2sca!4v1576782813196!5m2!1sen!2sca\" width=\"100%\" height=\"350\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\"></iframe>
    </div>
   </div>
</div>
<div class=\"container\">
  <div class=\"row\">
    <div class=\"col-12\">
  <div class=\"hs-ad\">
<i class=\"fas fa-map-marker-alt\"></i>
  <span>Highway 7 Leslie Street 75 West Wilmot St. Richmond Hill, Ontario L4B 0B7, Canada</span>
</div>
<div class=\"hs-ad\">
  <i class=\"fas fa-mobile-alt\"></i>
    <span>+1(514)566-0432</span>
</div>
<div class=\"hs-ad\">
  <i class=\"fas fa-phone-volume\"></i>
    <span>+1(514)566-0564</span>
</div>
<div class=\"hs-ad\">
  <i class=\"fas fa-phone-volume\"></i>
   <span>+1(514)566-4532</span>
</div>
</div>
</div>
</div>
<div class=\"container-fluid hs-footer\">
  <div class=\"row\">
   <div class=\"col-6\">
    <i class=\"far fa-copyright\"></i>
     <span>Designed by Nourolhoda Sayadi</span>
   </div>
     <div class=\"col-6 text-right social\">
      <i class=\"fab fa-twitter\"></i>
      <i class=\"fab fa-google-plus-g\"></i>
      <i class=\"fab fa-instagram\"></i>
      <i class=\"fab fa-facebook-f\"></i>
     </div>
   </div>
 </div>
{% endblock %}", "contact.html.twig", "C:\\xampp\\htdocs\\eleq_shop\\templates\\contact.html.twig");
    }
}
