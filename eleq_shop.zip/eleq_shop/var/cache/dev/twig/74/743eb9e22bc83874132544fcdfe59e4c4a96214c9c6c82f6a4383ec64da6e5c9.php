<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html.twig */
class __TwigTemplate_cc1b05ae0800acbfa1b34519b972d76b85b250597d403c24628775d410bd0897 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'active_home' => [$this, 'block_active_home'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_active_home($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_home"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_home"));

        echo " active ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "  <div class=\"hs-wel\">
    <div class=\"container\">
      <div class=\"row\">
       <div class=\"col-12\">
        <a href=\"#\">
         <i class=\"fas fa-home\"></i>
        </a>
        <span>/</span>
        <span>HOME</span>
        <span>/</span>
        <span>Welcome to MX Electronics</span>
        </div>
      </div>
    </div>
  </div>
<div class=\"container-fluid\">
<div class=\"row\">
<div id=\"carouselExampleCaptions\" class=\"carousel slide\" data-ride=\"carousel\">
  <ol class=\"carousel-indicators\">
    <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"0\" class=\"active\"></li>
    <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"1\"></li>
    <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"2\"></li>
     <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"3\"></li>
  </ol>
  <div class=\"carousel-inner\">
    <div class=\"carousel-item active\">
      <img src=\"../images/s1.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
    <div class=\"carousel-item \">
      <img src=\"../images/s2.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
    <div class=\"carousel-item \">
      <img src=\"../images/s3.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
    <div class=\"carousel-item \">
      <img src=\"../images/s4.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
  </div>
  <a class=\"carousel-control-prev\" href=\"#carouselExampleCaptions\" role=\"button\" data-slide=\"prev\">
    <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Previous</span>
   </a>
   <a class=\"carousel-control-next\" href=\"#carouselExampleCaptions\" role=\"button\" data-slide=\"next\">
    <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Next</span>
   </a>
  </div>
 </div>
</div>
<div class=\"container\">
  <div class=\"row mt-4 mb-2\">
   <h2 class=\"hs-tit\">
   <i class=\"fas fa-chevron-right\"></i>
   <i class=\"fas fa-chevron-right\"></i>
   <span>New Products</span>
   </h2>
  </div>
    <div class=\"row\">
      ";
        // line 72
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) || array_key_exists("products", $context) ? $context["products"] : (function () { throw new RuntimeError('Variable "products" does not exist.', 72, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 73
            echo "      <div class=\"col-4 mt-3 mb-3\">
        <div class=\"card\" style=\"width: 18rem;\">
         <img  src=\"";
            // line 75
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["product"], "image", [], "array", false, false, false, 75)), "html", null, true);
            echo "\" class=\"card-img-top\" alt=\"...\">
          <div class=\"card-body\">
           <h5 class=\"card-title\">";
            // line 77
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "name", [], "array", false, false, false, 77), "html", null, true);
            echo "</h5>
            <p class=\"card-text\">";
            // line 78
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "dis", [], "array", false, false, false, 78), "html", null, true);
            echo "</p>
          </div>
           <ul class=\"list-group list-group-flush\">
           <li class=\"list-group-item price1 text-center\">
             <i class=\"fas fa-dollar-sign\"></i>
             ";
            // line 83
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "price", [], "array", false, false, false, 83), "html", null, true);
            echo "
           </li>
            <li class=\"list-group-item price2 text-center\">
             <i class=\"fas fa-dollar-sign\"></i>
             ";
            // line 87
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "price-sale", [], "array", false, false, false, 87), "html", null, true);
            echo "
            </li>
          </ul>
        </div>
       </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 93
        echo "    </div>
</div>
<div class=\"container\">
  <div class=\"row mt-4 mb-2\">
    <h2 class=\"hs-tit\">
    <i class=\"fas fa-chevron-right\"></i>
    <i class=\"fas fa-chevron-right\"></i>
      <span>Promotion</span>
    </h2>
   </div>
   <div class=\"row\">
    ";
        // line 104
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) || array_key_exists("products", $context) ? $context["products"] : (function () { throw new RuntimeError('Variable "products" does not exist.', 104, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 105
            echo "     <div class=\"col-4 mt-3 mb-3\">
       <div class=\"card\" style=\"width: 18rem;\">
        <img  src=\"";
            // line 107
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(twig_get_attribute($this->env, $this->source, $context["product"], "image", [], "array", false, false, false, 107)), "html", null, true);
            echo "\" class=\"card-img-top\" alt=\"...\">
       <div class=\"card-body\">
        <h5 class=\"card-title\">";
            // line 109
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "name", [], "array", false, false, false, 109), "html", null, true);
            echo "</h5>
        <p class=\"card-text\">";
            // line 110
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "dis", [], "array", false, false, false, 110), "html", null, true);
            echo "</p>
       </div>
        <ul class=\"list-group list-group-flush\">
        <li class=\"list-group-item price1 text-center\">
          <i class=\"fas fa-dollar-sign\"></i>
        ";
            // line 115
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "price", [], "array", false, false, false, 115), "html", null, true);
            echo "
         </li>
         <li class=\"list-group-item price2 text-center\">
          <i class=\"fas fa-dollar-sign\"></i>
        ";
            // line 119
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["product"], "price-sale", [], "array", false, false, false, 119), "html", null, true);
            echo "
      </li>
    </ul>
   </div>
       </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 125
        echo "    </div>
</div>
  <div class=\"container-fluid hs-footer\">
    <div class=\"row\">
     <div class=\"col-6\">
       <i class=\"far fa-copyright\"></i>
        <span>Designed by Nourolhoda Sayadi</span>
     </div>
    <div class=\"col-6 text-right social\">
     <i class=\"fab fa-twitter\"></i>
      <i class=\"fab fa-google-plus-g\"></i>
       <i class=\"fab fa-instagram\"></i>
         <i class=\"fab fa-facebook-f\"></i>
    </div>
  </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 125,  245 => 119,  238 => 115,  230 => 110,  226 => 109,  221 => 107,  217 => 105,  213 => 104,  200 => 93,  188 => 87,  181 => 83,  173 => 78,  169 => 77,  164 => 75,  160 => 73,  156 => 72,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends ('base.html.twig') %}

{% block active_home %} active {% endblock %}

{% block body %}
  <div class=\"hs-wel\">
    <div class=\"container\">
      <div class=\"row\">
       <div class=\"col-12\">
        <a href=\"#\">
         <i class=\"fas fa-home\"></i>
        </a>
        <span>/</span>
        <span>HOME</span>
        <span>/</span>
        <span>Welcome to MX Electronics</span>
        </div>
      </div>
    </div>
  </div>
<div class=\"container-fluid\">
<div class=\"row\">
<div id=\"carouselExampleCaptions\" class=\"carousel slide\" data-ride=\"carousel\">
  <ol class=\"carousel-indicators\">
    <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"0\" class=\"active\"></li>
    <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"1\"></li>
    <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"2\"></li>
     <li data-target=\"#carouselExampleCaptions\" data-slide-to=\"3\"></li>
  </ol>
  <div class=\"carousel-inner\">
    <div class=\"carousel-item active\">
      <img src=\"../images/s1.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
    <div class=\"carousel-item \">
      <img src=\"../images/s2.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
    <div class=\"carousel-item \">
      <img src=\"../images/s3.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
    <div class=\"carousel-item \">
      <img src=\"../images/s4.jpg\" class=\"d-block w-100\" alt=\"...\">
      <div class=\"carousel-caption d-none d-md-block\">
      </div>
    </div>
  </div>
  <a class=\"carousel-control-prev\" href=\"#carouselExampleCaptions\" role=\"button\" data-slide=\"prev\">
    <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Previous</span>
   </a>
   <a class=\"carousel-control-next\" href=\"#carouselExampleCaptions\" role=\"button\" data-slide=\"next\">
    <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
    <span class=\"sr-only\">Next</span>
   </a>
  </div>
 </div>
</div>
<div class=\"container\">
  <div class=\"row mt-4 mb-2\">
   <h2 class=\"hs-tit\">
   <i class=\"fas fa-chevron-right\"></i>
   <i class=\"fas fa-chevron-right\"></i>
   <span>New Products</span>
   </h2>
  </div>
    <div class=\"row\">
      {% for product in products %}
      <div class=\"col-4 mt-3 mb-3\">
        <div class=\"card\" style=\"width: 18rem;\">
         <img  src=\"{{ asset(product['image']) }}\" class=\"card-img-top\" alt=\"...\">
          <div class=\"card-body\">
           <h5 class=\"card-title\">{{ product['name'] }}</h5>
            <p class=\"card-text\">{{ product['dis'] }}</p>
          </div>
           <ul class=\"list-group list-group-flush\">
           <li class=\"list-group-item price1 text-center\">
             <i class=\"fas fa-dollar-sign\"></i>
             {{ product['price'] }}
           </li>
            <li class=\"list-group-item price2 text-center\">
             <i class=\"fas fa-dollar-sign\"></i>
             {{ product['price-sale'] }}
            </li>
          </ul>
        </div>
       </div>
      {% endfor %}
    </div>
</div>
<div class=\"container\">
  <div class=\"row mt-4 mb-2\">
    <h2 class=\"hs-tit\">
    <i class=\"fas fa-chevron-right\"></i>
    <i class=\"fas fa-chevron-right\"></i>
      <span>Promotion</span>
    </h2>
   </div>
   <div class=\"row\">
    {% for product in products %}
     <div class=\"col-4 mt-3 mb-3\">
       <div class=\"card\" style=\"width: 18rem;\">
        <img  src=\"{{ asset(product['image']) }}\" class=\"card-img-top\" alt=\"...\">
       <div class=\"card-body\">
        <h5 class=\"card-title\">{{ product['name'] }}</h5>
        <p class=\"card-text\">{{ product['dis'] }}</p>
       </div>
        <ul class=\"list-group list-group-flush\">
        <li class=\"list-group-item price1 text-center\">
          <i class=\"fas fa-dollar-sign\"></i>
        {{ product['price'] }}
         </li>
         <li class=\"list-group-item price2 text-center\">
          <i class=\"fas fa-dollar-sign\"></i>
        {{ product['price-sale'] }}
      </li>
    </ul>
   </div>
       </div>
        {% endfor %}
    </div>
</div>
  <div class=\"container-fluid hs-footer\">
    <div class=\"row\">
     <div class=\"col-6\">
       <i class=\"far fa-copyright\"></i>
        <span>Designed by Nourolhoda Sayadi</span>
     </div>
    <div class=\"col-6 text-right social\">
     <i class=\"fab fa-twitter\"></i>
      <i class=\"fab fa-google-plus-g\"></i>
       <i class=\"fab fa-instagram\"></i>
         <i class=\"fab fa-facebook-f\"></i>
    </div>
  </div>
</div>
{% endblock %}
", "index.html.twig", "C:\\xampp\\htdocs\\eleq_shop\\templates\\index.html.twig");
    }
}
