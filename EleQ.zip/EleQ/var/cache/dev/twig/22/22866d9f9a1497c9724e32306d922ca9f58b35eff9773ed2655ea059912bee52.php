<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* product.html.twig */
class __TwigTemplate_13bf9abd556013a2ad9ba326517f21bcfe0ac553abeabe5d9d86d6a58453a3ae extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'active_contact' => [$this, 'block_active_contact'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "product.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "product.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "product.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_active_contact($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "active_contact"));

        echo " active ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<script>

\$('.minus-btn').on('click', function(e) {
    e.preventDefault();
    var \$this = \$(this);
    var \$input = \$this.closest('div').find('input');
    var value = parseInt(\$input.val());
 
    if (value &amp;gt; 1) {
        value = value - 1;
    } else {
        value = 0;
    }
 
  \$input.val(value);
 
});
 
\$('.plus-btn').on('click', function(e) {
    e.preventDefault();
    var \$this = \$(this);
    var \$input = \$this.closest('div').find('input');
    var value = parseInt(\$input.val());
 
    if (value &amp;lt; 100) {
        value = value + 1;
    } else {
        value =100;
    }
 
    \$input.val(value);
});
</script>
<style> {
  box-sizing: border-box;
}
 
html,
body {
  width: 100%;
  height: 100%;
  margin: 0;
  background-color: #7EC855;
  font-family: 'Roboto', sans-serif;
}
.shopping-cart {
  width: 750px;
  height: 423px;
  margin: 80px auto;
  background: #FFFFFF;
  box-shadow: 1px 2px 3px 0px rgba(0,0,0,0.10);
  border-radius: 6px;
 
  display: flex;
  flex-direction: column;
}
.title {
  height: 60px;
  border-bottom: 1px solid #E1E8EE;
  padding: 20px 30px;
  color: #5E6977;
  font-size: 18px;
  font-weight: 400;
}
 
.item {
  padding: 20px 30px;
  height: 120px;
  display: flex;
}
 
.item:nth-child(3) {
  border-top:  1px solid #E1E8EE;
  border-bottom:  1px solid #E1E8EE;
}
.buttons {
  position: relative;
  padding-top: 30px;
  margin-right: 60px;
}
.delete-btn,
.like-btn {
  display: inline-block;
  Cursor: pointer;
}
.delete-btn {
  width: 18px;
  height: 17px;
  background: url(&quot;delete-icn.svg&quot;) no-repeat center;
}
 
.like-btn {
  position: absolute;
  top: 9px;
  left: 15px;
  background: url('twitter-heart.png');
  width: 60px;
  height: 60px;
  background-size: 2900%;
  background-repeat: no-repeat;
}
.is-active {
  animation-name: animate;
  animation-duration: .8s;
  animation-iteration-count: 1;
  animation-timing-function: steps(28);
  animation-fill-mode: forwards;
}
 
@keyframes animate {
  0%   { background-position: left;  }
  50%  { background-position: right; }
  100% { background-position: right; }
}
.image {
  margin-right: 50px;
}
 
Let’s add some basic style to  product name and description.
.description {
  padding-top: 10px;
  margin-right: 60px;
  width: 115px;
}
 
.description span {
  display: block;
  font-size: 14px;
  color: #43484D;
  font-weight: 400;
}
 
.description span:first-child {
  margin-bottom: 5px;
}
.description span:last-child {
  font-weight: 300;
  margin-top: 8px;
  color: #86939E;
}
.total-price {
  width: 83px;
  padding-top: 27px;
  text-align: center;
  font-size: 16px;
  color: #43484D;
  font-weight: 300;
}
.quantity {
  padding-top: 20px;
  margin-right: 60px;
}
.quantity input {
  -webkit-appearance: none;
  border: none;
  text-align: center;
  width: 32px;
  font-size: 16px;
  color: #43484D;
  font-weight: 300;
}
 
button[class*=btn] {
  width: 30px;
  height: 30px;
  background-color: #E1E8EE;
  border-radius: 6px;
  border: none;
  cursor: pointer;
}
.minus-btn img {
  margin-bottom: 3px;
}
.plus-btn img {
  margin-top: 2px;
}
 
button:focus,
input:focus {
  outline:0;
}
@media (max-width: 800px) {
  .shopping-cart {
    width: 100%;
    height: auto;
    overflow: hidden;
  }
  .item {
    height: auto;
    flex-wrap: wrap;
    justify-content: center;
  }
  .image img {
    width: 50%;
  }
  .image,
  .quantity,
  .description {
    width: 100%;
    text-align: center;
    margin: 6px 0;
  }
  .buttons {
    margin-right: 20px;
  }
}
</style>

    <div class=\"shopping-cart\">
  <!-- Title -->
  <div class=\"title\">
    Shopping Bag
  </div>
 
  <!-- Product #1 -->
  <div class=\"item\">
    <div class=\"buttons\">
      <span class=\"delete-btn\"></span>
      <span class=\"like-btn\"></span>
    </div>
 
    <div class=\"image\">
      <img src=\"image/image1.jpg\" style = \"height: 100px; width: 130px;\" alt=\"\" />
    </div>
 
    <div class=\"description\">
      <span>Google Home</span>
      <span>with Smart</span>
      <span>bulb</span>
    </div>
 
    <div class=\"quantity\">
      <button class=\"plus-btn\" type=\"button\" name=\"button\">
        <img src=\"image/plus.png\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
      <input type=\"text\" name=\"name\" value=\"1\">
      <button class=\"minus-btn\" type=\"button\" name=\"button\">
        <img src=\"image/minus.jpg\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
    </div>
 
    <div class=\"total-price\">\$200</div>
  </div>
 
  <!-- Product #2 -->
  <div class=\"item\">
    <div class=\"buttons\">
      <span class=\"delete-btn\"></span>
      <span class=\"like-btn\"></span>
    </div>
 
    <div class=\"image\">
     <img src=\"image/image2.jpg\" style = \"height: 100px; width: 130px;\" alt=\"\" />
    </div>
 
    <div class=\"description\">
      <span>Oculus Rift</span>
      <span>by</span>
      <span>Facebook</span>
    </div>
 
    <div class=\"quantity\">
      <button class=\"plus-btn\" type=\"button\" name=\"button\">
           <img src=\"image/plus.png\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
      <input type=\"text\" name=\"name\" value=\"1\">
      <button class=\"minus-btn\" type=\"button\" name=\"button\">
        <img src=\"image/minus.jpg\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
    </div>
 
    <div class=\"total-price\">\$700</div>
  </div>
 
  <!-- Product #3 -->
  <div class=\"item\">
    <div class=\"buttons\">
      <span class=\"delete-btn\"></span>
      <span class=\"like-btn\"></span>
    </div>
 
    <div class=\"image\">
      <img src=\"image/image3.jpg\" style = \"height: 100px; width: 130px;\" alt=\"\" />
    </div>
 
    <div class=\"description\">
      <span>Playstation Pro</span>
      <span>4 by</span>
      <span>Sony</span>
    </div>
 
    <div class=\"quantity\">
      <button class=\"plus-btn\" type=\"button\" name=\"button\">
       <img src=\"image/plus.png\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
      <input type=\"text\" name=\"name\" value=\"1\">
      <button class=\"minus-btn\" type=\"button\" name=\"button\">
       <img src=\"image/minus.jpg\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
    </div>
 
    <div class=\"total-price\">\$349</div>
  </div>
<form action=\"";
        // line 310
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("cart");
        echo "\" method=\"POST\">
                   <div class=\"modal-footer\">
                        
                        <button type=\"submit\" class=\"btn btn-primary\" style=\"height: 20px; width: 40px;\">Cart</button>

                    </div>
                </form>
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  393 => 310,  88 => 7,  78 => 6,  59 => 4,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends ('base.html.twig') %}


{% block active_contact %} active {% endblock %}

{% block body %}
<script>

\$('.minus-btn').on('click', function(e) {
    e.preventDefault();
    var \$this = \$(this);
    var \$input = \$this.closest('div').find('input');
    var value = parseInt(\$input.val());
 
    if (value &amp;gt; 1) {
        value = value - 1;
    } else {
        value = 0;
    }
 
  \$input.val(value);
 
});
 
\$('.plus-btn').on('click', function(e) {
    e.preventDefault();
    var \$this = \$(this);
    var \$input = \$this.closest('div').find('input');
    var value = parseInt(\$input.val());
 
    if (value &amp;lt; 100) {
        value = value + 1;
    } else {
        value =100;
    }
 
    \$input.val(value);
});
</script>
<style> {
  box-sizing: border-box;
}
 
html,
body {
  width: 100%;
  height: 100%;
  margin: 0;
  background-color: #7EC855;
  font-family: 'Roboto', sans-serif;
}
.shopping-cart {
  width: 750px;
  height: 423px;
  margin: 80px auto;
  background: #FFFFFF;
  box-shadow: 1px 2px 3px 0px rgba(0,0,0,0.10);
  border-radius: 6px;
 
  display: flex;
  flex-direction: column;
}
.title {
  height: 60px;
  border-bottom: 1px solid #E1E8EE;
  padding: 20px 30px;
  color: #5E6977;
  font-size: 18px;
  font-weight: 400;
}
 
.item {
  padding: 20px 30px;
  height: 120px;
  display: flex;
}
 
.item:nth-child(3) {
  border-top:  1px solid #E1E8EE;
  border-bottom:  1px solid #E1E8EE;
}
.buttons {
  position: relative;
  padding-top: 30px;
  margin-right: 60px;
}
.delete-btn,
.like-btn {
  display: inline-block;
  Cursor: pointer;
}
.delete-btn {
  width: 18px;
  height: 17px;
  background: url(&quot;delete-icn.svg&quot;) no-repeat center;
}
 
.like-btn {
  position: absolute;
  top: 9px;
  left: 15px;
  background: url('twitter-heart.png');
  width: 60px;
  height: 60px;
  background-size: 2900%;
  background-repeat: no-repeat;
}
.is-active {
  animation-name: animate;
  animation-duration: .8s;
  animation-iteration-count: 1;
  animation-timing-function: steps(28);
  animation-fill-mode: forwards;
}
 
@keyframes animate {
  0%   { background-position: left;  }
  50%  { background-position: right; }
  100% { background-position: right; }
}
.image {
  margin-right: 50px;
}
 
Let’s add some basic style to  product name and description.
.description {
  padding-top: 10px;
  margin-right: 60px;
  width: 115px;
}
 
.description span {
  display: block;
  font-size: 14px;
  color: #43484D;
  font-weight: 400;
}
 
.description span:first-child {
  margin-bottom: 5px;
}
.description span:last-child {
  font-weight: 300;
  margin-top: 8px;
  color: #86939E;
}
.total-price {
  width: 83px;
  padding-top: 27px;
  text-align: center;
  font-size: 16px;
  color: #43484D;
  font-weight: 300;
}
.quantity {
  padding-top: 20px;
  margin-right: 60px;
}
.quantity input {
  -webkit-appearance: none;
  border: none;
  text-align: center;
  width: 32px;
  font-size: 16px;
  color: #43484D;
  font-weight: 300;
}
 
button[class*=btn] {
  width: 30px;
  height: 30px;
  background-color: #E1E8EE;
  border-radius: 6px;
  border: none;
  cursor: pointer;
}
.minus-btn img {
  margin-bottom: 3px;
}
.plus-btn img {
  margin-top: 2px;
}
 
button:focus,
input:focus {
  outline:0;
}
@media (max-width: 800px) {
  .shopping-cart {
    width: 100%;
    height: auto;
    overflow: hidden;
  }
  .item {
    height: auto;
    flex-wrap: wrap;
    justify-content: center;
  }
  .image img {
    width: 50%;
  }
  .image,
  .quantity,
  .description {
    width: 100%;
    text-align: center;
    margin: 6px 0;
  }
  .buttons {
    margin-right: 20px;
  }
}
</style>

    <div class=\"shopping-cart\">
  <!-- Title -->
  <div class=\"title\">
    Shopping Bag
  </div>
 
  <!-- Product #1 -->
  <div class=\"item\">
    <div class=\"buttons\">
      <span class=\"delete-btn\"></span>
      <span class=\"like-btn\"></span>
    </div>
 
    <div class=\"image\">
      <img src=\"image/image1.jpg\" style = \"height: 100px; width: 130px;\" alt=\"\" />
    </div>
 
    <div class=\"description\">
      <span>Google Home</span>
      <span>with Smart</span>
      <span>bulb</span>
    </div>
 
    <div class=\"quantity\">
      <button class=\"plus-btn\" type=\"button\" name=\"button\">
        <img src=\"image/plus.png\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
      <input type=\"text\" name=\"name\" value=\"1\">
      <button class=\"minus-btn\" type=\"button\" name=\"button\">
        <img src=\"image/minus.jpg\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
    </div>
 
    <div class=\"total-price\">\$200</div>
  </div>
 
  <!-- Product #2 -->
  <div class=\"item\">
    <div class=\"buttons\">
      <span class=\"delete-btn\"></span>
      <span class=\"like-btn\"></span>
    </div>
 
    <div class=\"image\">
     <img src=\"image/image2.jpg\" style = \"height: 100px; width: 130px;\" alt=\"\" />
    </div>
 
    <div class=\"description\">
      <span>Oculus Rift</span>
      <span>by</span>
      <span>Facebook</span>
    </div>
 
    <div class=\"quantity\">
      <button class=\"plus-btn\" type=\"button\" name=\"button\">
           <img src=\"image/plus.png\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
      <input type=\"text\" name=\"name\" value=\"1\">
      <button class=\"minus-btn\" type=\"button\" name=\"button\">
        <img src=\"image/minus.jpg\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
    </div>
 
    <div class=\"total-price\">\$700</div>
  </div>
 
  <!-- Product #3 -->
  <div class=\"item\">
    <div class=\"buttons\">
      <span class=\"delete-btn\"></span>
      <span class=\"like-btn\"></span>
    </div>
 
    <div class=\"image\">
      <img src=\"image/image3.jpg\" style = \"height: 100px; width: 130px;\" alt=\"\" />
    </div>
 
    <div class=\"description\">
      <span>Playstation Pro</span>
      <span>4 by</span>
      <span>Sony</span>
    </div>
 
    <div class=\"quantity\">
      <button class=\"plus-btn\" type=\"button\" name=\"button\">
       <img src=\"image/plus.png\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
      <input type=\"text\" name=\"name\" value=\"1\">
      <button class=\"minus-btn\" type=\"button\" name=\"button\">
       <img src=\"image/minus.jpg\" style = \"height: 20px; width: 20px;\" alt=\"\" />
      </button>
    </div>
 
    <div class=\"total-price\">\$349</div>
  </div>
<form action=\"{{ path('cart') }}\" method=\"POST\">
                   <div class=\"modal-footer\">
                        
                        <button type=\"submit\" class=\"btn btn-primary\" style=\"height: 20px; width: 40px;\">Cart</button>

                    </div>
                </form>
</div>

{% endblock %}", "product.html.twig", "C:\\xampp\\htdocs\\EleQ\\templates\\product.html.twig");
    }
}
